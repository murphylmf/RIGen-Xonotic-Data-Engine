# Microsoft Developer Studio Project File - Name="darkplaces-dedicated" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=darkplaces-dedicated - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "darkplaces-dedicated.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "darkplaces-dedicated.mak" CFG="darkplaces-dedicated - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "darkplaces-dedicated - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "darkplaces-dedicated - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "darkplaces-dedicated - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release-Dedicated"
# PROP Intermediate_Dir "Release-Dedicated"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_MBCS" /D "_FILE_OFFSET_BITS=64" /D "__KERNEL_STRICT_NAMES" /YX /FD /c
# ADD CPP /nologo /MD /W3 /GX /Ox /Ot /Og /Oi /Op /D "WIN32" /D "WIN32_LEAN_AND_MEAN" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /D "_FILE_OFFSET_BITS=64" /D "__KERNEL_STRICT_NAMES" /YX /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x40c /d "NDEBUG"
# ADD RSC /l 0x40c /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib /nologo /subsystem:windows /machine:I386
# ADD LINK32 ws2_32.lib winmm.lib user32.lib gdi32.lib /nologo /subsystem:console /LARGEADDRESSAWARE /machine:I386
# SUBTRACT LINK32 /pdb:none

!ELSEIF  "$(CFG)" == "darkplaces-dedicated - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug-Dedicated"
# PROP Intermediate_Dir "Debug-Dedicated"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_MBCS" /D "_FILE_OFFSET_BITS=64" /D "__KERNEL_STRICT_NAMES" /YX /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "WIN32_LEAN_AND_MEAN" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /D "_FILE_OFFSET_BITS=64" /D "__KERNEL_STRICT_NAMES" /YX /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x40c /d "_DEBUG"
# ADD RSC /l 0x40c /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 ws2_32.lib winmm.lib user32.lib gdi32.lib /nologo /subsystem:console /LARGEADDRESSAWARE /debug /machine:I386 /out:"Debug-Dedicated/darkplaces-dedicated-debug.exe" /pdbtype:sept
# SUBTRACT LINK32 /pdb:none

!ENDIF 

# Begin Target

# Name "darkplaces-dedicated - Win32 Release"
# Name "darkplaces-dedicated - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\builddate.c
# End Source File
# Begin Source File

SOURCE=.\cd_null.c
# End Source File
# Begin Source File

SOURCE=.\cd_shared.c
# End Source File
# Begin Source File

SOURCE=.\cl_collision.c
# End Source File
# Begin Source File

SOURCE=.\cl_demo.c
# End Source File
# Begin Source File

SOURCE=.\cl_dyntexture.h
# End Source File
# Begin Source File

SOURCE=.\cl_gecko.h
# End Source File
# Begin Source File

SOURCE=.\cl_input.c
# End Source File
# Begin Source File

SOURCE=.\cl_main.c
# End Source File
# Begin Source File

SOURCE=.\cl_parse.c
# End Source File
# Begin Source File

SOURCE=.\cl_particles.c
# End Source File
# Begin Source File

SOURCE=.\cl_screen.c
# End Source File
# Begin Source File

SOURCE=.\cl_video.c
# End Source File
# Begin Source File

SOURCE=.\clvm_cmds.c
# End Source File
# Begin Source File

SOURCE=.\cmd.c
# End Source File
# Begin Source File

SOURCE=.\collision.c
# End Source File
# Begin Source File

SOURCE=.\common.c
# End Source File
# Begin Source File

SOURCE=.\console.c
# End Source File
# Begin Source File

SOURCE=.\csprogs.c
# End Source File
# Begin Source File

SOURCE=.\curves.c
# End Source File
# Begin Source File

SOURCE=.\cvar.c
# End Source File
# Begin Source File

SOURCE=.\darkplaces.rc
# End Source File
# Begin Source File

SOURCE=.\dpvsimpledecode.c
# End Source File
# Begin Source File

SOURCE=.\filematch.c
# End Source File
# Begin Source File

SOURCE=.\fractalnoise.c
# End Source File
# Begin Source File

SOURCE=.\fs.c
# End Source File
# Begin Source File

SOURCE=.\gl_backend.c
# End Source File
# Begin Source File

SOURCE=.\gl_draw.c
# End Source File
# Begin Source File

SOURCE=.\gl_rmain.c
# End Source File
# Begin Source File

SOURCE=.\gl_rsurf.c
# End Source File
# Begin Source File

SOURCE=.\gl_textures.c
# End Source File
# Begin Source File

SOURCE=.\host.c
# End Source File
# Begin Source File

SOURCE=.\host_cmd.c
# End Source File
# Begin Source File

SOURCE=.\image.c
# End Source File
# Begin Source File

SOURCE=.\image_png.c
# End Source File
# Begin Source File

SOURCE=.\jpeg.c
# End Source File
# Begin Source File

SOURCE=.\keys.c
# End Source File
# Begin Source File

SOURCE=.\lhnet.c
# End Source File
# Begin Source File

SOURCE=.\libcurl.c
# End Source File
# Begin Source File

SOURCE=.\mathlib.c
# End Source File
# Begin Source File

SOURCE=.\matrixlib.c
# End Source File
# Begin Source File

SOURCE=.\mdfour.c
# End Source File
# Begin Source File

SOURCE=.\menu.c
# End Source File
# Begin Source File

SOURCE=.\meshqueue.c
# End Source File
# Begin Source File

SOURCE=.\model_alias.c
# End Source File
# Begin Source File

SOURCE=.\model_brush.c
# End Source File
# Begin Source File

SOURCE=.\model_shared.c
# End Source File
# Begin Source File

SOURCE=.\model_sprite.c
# End Source File
# Begin Source File

SOURCE=.\mvm_cmds.c
# End Source File
# Begin Source File

SOURCE=.\netconn.c
# End Source File
# Begin Source File

SOURCE=.\palette.c
# End Source File
# Begin Source File

SOURCE=.\polygon.c
# End Source File
# Begin Source File

SOURCE=.\portals.c
# End Source File
# Begin Source File

SOURCE=.\protocol.c
# End Source File
# Begin Source File

SOURCE=.\prvm_cmds.c
# End Source File
# Begin Source File

SOURCE=.\prvm_edict.c
# End Source File
# Begin Source File

SOURCE=.\prvm_exec.c
# End Source File
# Begin Source File

SOURCE=.\r_explosion.c
# End Source File
# Begin Source File

SOURCE=.\r_lerpanim.c
# End Source File
# Begin Source File

SOURCE=.\r_lightning.c
# End Source File
# Begin Source File

SOURCE=.\r_modules.c
# End Source File
# Begin Source File

SOURCE=.\r_shadow.c
# End Source File
# Begin Source File

SOURCE=.\r_sky.c
# End Source File
# Begin Source File

SOURCE=.\r_sprites.c
# End Source File
# Begin Source File

SOURCE=.\sbar.c
# End Source File
# Begin Source File

SOURCE=.\snd_null.c
# End Source File
# Begin Source File

SOURCE=.\sv_demo.c
# End Source File
# Begin Source File

SOURCE=.\sv_main.c
# End Source File
# Begin Source File

SOURCE=.\sv_move.c
# End Source File
# Begin Source File

SOURCE=.\sv_phys.c
# End Source File
# Begin Source File

SOURCE=.\sv_user.c
# End Source File
# Begin Source File

SOURCE=.\svbsp.c
# End Source File
# Begin Source File

SOURCE=.\svvm_cmds.c
# End Source File
# Begin Source File

SOURCE=.\sys_linux.c
# End Source File
# Begin Source File

SOURCE=.\sys_shared.c
# End Source File
# Begin Source File

SOURCE=.\vid_null.c
# End Source File
# Begin Source File

SOURCE=.\vid_shared.c
# End Source File
# Begin Source File

SOURCE=.\view.c
# End Source File
# Begin Source File

SOURCE=.\wad.c
# End Source File
# Begin Source File

SOURCE=.\world.c
# End Source File
# Begin Source File

SOURCE=.\zone.c
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\bspfile.h
# End Source File
# Begin Source File

SOURCE=.\cdaudio.h
# End Source File
# Begin Source File

SOURCE=.\cl_collision.h
# End Source File
# Begin Source File

SOURCE=.\cl_dyntexture.h
# End Source File
# Begin Source File

SOURCE=.\cl_gecko.h
# End Source File
# Begin Source File

SOURCE=.\cl_screen.h
# End Source File
# Begin Source File

SOURCE=.\cl_video.h
# End Source File
# Begin Source File

SOURCE=.\client.h
# End Source File
# Begin Source File

SOURCE=.\clprogdefs.h
# End Source File
# Begin Source File

SOURCE=.\cmd.h
# End Source File
# Begin Source File

SOURCE=.\collision.h
# End Source File
# Begin Source File

SOURCE=.\common.h
# End Source File
# Begin Source File

SOURCE=.\console.h
# End Source File
# Begin Source File

SOURCE=.\csprogs.h
# End Source File
# Begin Source File

SOURCE=.\curves.h
# End Source File
# Begin Source File

SOURCE=.\cvar.h
# End Source File
# Begin Source File

SOURCE=.\dpvsimpledecode.h
# End Source File
# Begin Source File

SOURCE=.\draw.h
# End Source File
# Begin Source File

SOURCE=.\fs.h
# End Source File
# Begin Source File

SOURCE=.\gl_backend.h
# End Source File
# Begin Source File

SOURCE=.\glquake.h
# End Source File
# Begin Source File

SOURCE=.\image.h
# End Source File
# Begin Source File

SOURCE=.\image_png.h
# End Source File
# Begin Source File

SOURCE=.\input.h
# End Source File
# Begin Source File

SOURCE=.\jpeg.h
# End Source File
# Begin Source File

SOURCE=.\keys.h
# End Source File
# Begin Source File

SOURCE=.\lhfont.h
# End Source File
# Begin Source File

SOURCE=.\lhnet.h
# End Source File
# Begin Source File

SOURCE=.\libcurl.h
# End Source File
# Begin Source File

SOURCE=.\mathlib.h
# End Source File
# Begin Source File

SOURCE=.\matrixlib.h
# End Source File
# Begin Source File

SOURCE=.\mdfour.h
# End Source File
# Begin Source File

SOURCE=.\menu.h
# End Source File
# Begin Source File

SOURCE=.\meshqueue.h
# End Source File
# Begin Source File

SOURCE=.\model_alias.h
# End Source File
# Begin Source File

SOURCE=.\model_brush.h
# End Source File
# Begin Source File

SOURCE=.\model_dpmodel.h
# End Source File
# Begin Source File

SOURCE=.\model_psk.h
# End Source File
# Begin Source File

SOURCE=.\model_shared.h
# End Source File
# Begin Source File

SOURCE=.\model_sprite.h
# End Source File
# Begin Source File

SOURCE=.\model_zymotic.h
# End Source File
# Begin Source File

SOURCE=.\modelgen.h
# End Source File
# Begin Source File

SOURCE=.\mprogdefs.h
# End Source File
# Begin Source File

SOURCE=.\netconn.h
# End Source File
# Begin Source File

SOURCE=.\palette.h
# End Source File
# Begin Source File

SOURCE=.\polygon.h
# End Source File
# Begin Source File

SOURCE=.\portals.h
# End Source File
# Begin Source File

SOURCE=.\pr_comp.h
# End Source File
# Begin Source File

SOURCE=.\pr_execprogram.h
# End Source File
# Begin Source File

SOURCE=.\progdefs.h
# End Source File
# Begin Source File

SOURCE=.\progs.h
# End Source File
# Begin Source File

SOURCE=.\progsvm.h
# End Source File
# Begin Source File

SOURCE=.\protocol.h
# End Source File
# Begin Source File

SOURCE=.\prvm_cmds.h
# End Source File
# Begin Source File

SOURCE=.\prvm_execprogram.h
# End Source File
# Begin Source File

SOURCE=.\qtypes.h
# End Source File
# Begin Source File

SOURCE=.\quakedef.h
# End Source File
# Begin Source File

SOURCE=.\r_lerpanim.h
# End Source File
# Begin Source File

SOURCE=.\r_modules.h
# End Source File
# Begin Source File

SOURCE=.\r_shadow.h
# End Source File
# Begin Source File

SOURCE=.\r_textures.h
# End Source File
# Begin Source File

SOURCE=.\render.h
# End Source File
# Begin Source File

SOURCE=.\sbar.h
# End Source File
# Begin Source File

SOURCE=.\screen.h
# End Source File
# Begin Source File

SOURCE=.\server.h
# End Source File
# Begin Source File

SOURCE=.\snd_main.h
# End Source File
# Begin Source File

SOURCE=.\sound.h
# End Source File
# Begin Source File

SOURCE=.\spritegn.h
# End Source File
# Begin Source File

SOURCE=.\sv_demo.h
# End Source File
# Begin Source File

SOURCE=.\svbsp.h
# End Source File
# Begin Source File

SOURCE=.\sys.h
# End Source File
# Begin Source File

SOURCE=.\vid.h
# End Source File
# Begin Source File

SOURCE=.\wad.h
# End Source File
# Begin Source File

SOURCE=.\world.h
# End Source File
# Begin Source File

SOURCE=.\zone.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\darkplaces.ico
# End Source File
# Begin Source File

SOURCE=.\darkplaces.rc
# End Source File
# Begin Source File

SOURCE=.\resource.h
# End Source File
# End Group
# End Target
# End Project
